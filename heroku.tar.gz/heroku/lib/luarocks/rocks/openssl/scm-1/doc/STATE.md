
compat with luasec 0.5 test result
----------------------

please see test/luasc

|what        |Result |Desc    |
|------------|-------|--------|
|certs       |*      |Not Lua | 
|chain       |pass   |        |
|dhparam     |pass   |        | 
|digest      |pass   |        |
|ecdh        |pass   |        |
|info        |pass   |        |
|key         |pass   |        |
|loop        |pass   |        |
|loop-gc     |pass   |        |
|oneshot     |pass   |        |
|verification|pass   |        |
|+fail-string|pass   |        |
|+fail-table |pass   |        |
|+success    |pass   |        |
|verify      |pass   |        |
|wantread    |NYI    |        |
|wantwrite   |NYI    |        |
|want        |NYI    |        |
