.. cmake-module:: ../../Modules/FindAVIFile.cmake
