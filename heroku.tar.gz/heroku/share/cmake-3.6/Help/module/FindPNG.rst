.. cmake-module:: ../../Modules/FindPNG.cmake
