.. cmake-module:: ../../Modules/FindosgUtil.cmake
