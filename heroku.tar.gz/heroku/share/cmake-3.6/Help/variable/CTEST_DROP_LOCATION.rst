CTEST_DROP_LOCATION
-------------------

Specify the CTest ``DropLocation`` setting
in a :manual:`ctest(1)` dashboard client script.
